<?php
// HTTP
define('HTTP_SERVER', 'http://nvinfobase.com/demo/development/tahir/admin/');
define('HTTP_CATALOG', 'http://nvinfobase.com/demo/development/tahir/');

// HTTPS
define('HTTPS_SERVER', 'http://nvinfobase.com/demo/development/tahir/admin/');
define('HTTPS_CATALOG', 'http://nvinfobase.com/demo/development/tahir/');

// DIR
define('DIR_APPLICATION', '/home/nvnfb7as/public_html/demo/development/tahir/admin/');
define('DIR_SYSTEM', '/home/nvnfb7as/public_html/demo/development/tahir/system/');
define('DIR_LANGUAGE', '/home/nvnfb7as/public_html/demo/development/tahir/admin/language/');
define('DIR_TEMPLATE', '/home/nvnfb7as/public_html/demo/development/tahir/admin/view/template/');
define('DIR_CONFIG', '/home/nvnfb7as/public_html/demo/development/tahir/system/config/');
define('DIR_IMAGE', '/home/nvnfb7as/public_html/demo/development/tahir/image/');
define('DIR_CACHE', '/home/nvnfb7as/public_html/demo/development/tahir/system/cache/');
define('DIR_DOWNLOAD', '/home/nvnfb7as/public_html/demo/development/tahir/system/download/');
define('DIR_UPLOAD', '/home/nvnfb7as/public_html/demo/development/tahir/system/upload/');
define('DIR_LOGS', '/home/nvnfb7as/public_html/demo/development/tahir/system/logs/');
define('DIR_MODIFICATION', '/home/nvnfb7as/public_html/demo/development/tahir/system/modification/');
define('DIR_CATALOG', '/home/nvnfb7as/public_html/demo/development/tahir/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'nvnfb7as_common');
define('DB_PASSWORD', 'common123');
define('DB_DATABASE', 'nvnfb7as_customkurta');
define('DB_PREFIX', 'oc_');
